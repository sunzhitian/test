package com.example.niconico.myapplication9;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    TextView textView;
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;
    Button button0;
    Button add;//加
    Button cut;//减
    Button rid;//乘
    Button divide;//除
    Button result;
    Button point;
    Button clear;
    Button sin;
    Button cos;
    Button tan;
    Button power;
    Button tra;
    int pointCount=0;
    int option = 0;//运算符状态
    boolean newdigital=true;//标记是否是新输入的数字
    boolean flag=true;//判断程序是否出错
    double a=0,b=0;//两个相加的数
    double sum=0;
    double sumtype=0;//判断输出的数是否有小数
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        textView=(TextView)findViewById(R.id.textView);
        button1=(Button)findViewById(R.id.btn1);
        button2=(Button)findViewById(R.id.btn2);
        button3=(Button)findViewById(R.id.btn3);
        button4=(Button)findViewById(R.id.btn4);
        button5=(Button)findViewById(R.id.btn5);
        button6=(Button)findViewById(R.id.btn6);
        button7=(Button)findViewById(R.id.btn7);
        button8=(Button)findViewById(R.id.btn8);
        button9=(Button)findViewById(R.id.btn9);
        button0=(Button)findViewById(R.id.btn0);
        add=(Button)findViewById(R.id.add);
        cut=(Button)findViewById(R.id.cut);
        rid=(Button)findViewById(R.id.rid);
        divide=(Button)findViewById(R.id.divide);
        result=(Button)findViewById(R.id.btnResult);
        point=(Button)findViewById(R.id.btnPoint);
        clear=(Button)findViewById(R.id.clear);
        sin=(Button)findViewById(R.id.sin);
        cos=(Button)findViewById(R.id.cos);
        tan=(Button)findViewById(R.id.tan);
        power=(Button)findViewById(R.id.平方);
        tra=(Button)findViewById(R.id.tra);

        button0.setOnClickListener(lisenter);
        button1.setOnClickListener(lisenter);
        button2.setOnClickListener(lisenter);
        button3.setOnClickListener(lisenter);
        button4.setOnClickListener(lisenter);
        button5.setOnClickListener(lisenter);
        button6.setOnClickListener(lisenter);
        button7.setOnClickListener(lisenter);
        button8.setOnClickListener(lisenter);
        button9.setOnClickListener(lisenter);
        add.setOnClickListener(lisenter);
        cut.setOnClickListener(lisenter);
        rid.setOnClickListener(lisenter);
        divide.setOnClickListener(lisenter);
        result.setOnClickListener(lisenter);
        point.setOnClickListener(lisenter);
        clear.setOnClickListener(lisenter);
        sin.setOnClickListener(lisenter);
        cos.setOnClickListener(lisenter);
        tan.setOnClickListener(lisenter);
        power.setOnClickListener(lisenter);
        tra.setOnClickListener(lisenter);



    }
View.OnClickListener lisenter=new View.OnClickListener() {


        public void onClick(View v) {
            TextView text = (TextView) findViewById(R.id.textView);
            String s = text.getText().toString();
            Button btn =(Button)v;
            String t=(String) btn.getText();

            if(btn.getId()==R.id.btn0||btn.getId()==R.id.btn1||btn.getId()==R.id.btn2||btn.getId()==R.id.btn3
                    ||btn.getId()==R.id.btn4||btn.getId()==R.id.btn5||btn.getId()==R.id.btn6||
                    btn.getId()==R.id.btn7||btn.getId()==R.id.btn8||btn.getId()==R.id.btn9||(btn.getId()==R.id.btnPoint&&pointCount==0))
            {


                if(btn.getId()==R.id.btnPoint){
                    if(null==s||s.equals("")){
                        s+=""+btn.getText();
                    }else{
                        s+=btn.getText();
                    }
                    pointCount=1;
                }else{
                    s+=btn.getText();
                }
                text.setText(s);

            }

            if(btn.getId()==R.id.rid||btn.getId()==R.id.add||btn.getId()==R.id.divide||btn.getId()==R.id.cut||btn.getId()==R.id.sin||btn.getId()==R.id.cos||btn.getId()==R.id.tan||btn.getId()==R.id.平方||btn.getId()==R.id.tra){

                if(null==s||s.equals("")){
                    s="0";
                }
                if(option!=0){
                    b=Double.valueOf(s);
                    switch (option) {
                        case 1:
                            sum=a+b;
                            break;
                        case 2:
                            sum=a-b;
                            break;
                        case 3:
                            sum=a*b;
                            break;
                        case 4:
                            if(b==0){
                                Toast.makeText(MainActivity.this, "0不能为除数", Toast.LENGTH_LONG).show();
                                text.setText("");
                                break;
                            }
                            sum=a/b;
                            break;
                        default:
                            break;
                    }
                    a=sum;

                }
                if(option==0){
                    a=Double.valueOf(s);
                }
                switch (btn.getId()) {
                    case R.id.add:
                        option=1;
                        break;
                    case R.id.cut:
                        option=2;
                        break;
                    case R.id.rid:
                        option=3;
                        break;
                    case R.id.divide:
                        option=4;
                        break;
                    case R.id.sin:
                        option=5;
                        break;
                    case R.id.cos:
                        option=6;
                        break;
                    case R.id.tan:
                        option=7;
                        break;
                    case R.id.平方:
                        option=8;
                        break;
                    case R.id.tra:
                        option=9;
                        break;
                    default:
                        break;
                }

                text.setText("0");
                pointCount=0;

            }

            if(btn.getId()==R.id.btnResult){
                if(null==s||s.equals("")){
                    s="0";
                }
                b=Double.valueOf(s);
                switch (option) {
                    case 1:
                        sum=a+b;
                        break;
                    case 2:
                        sum=a-b;
                        break;
                    case 3:
                        sum=a*b;
                        break;
                    case 4:
                        if(b==0){
                            Toast.makeText(MainActivity.this, "0不能为除数", Toast.LENGTH_LONG).show();
                            text.setText("");
                            flag=false;
                            break;
                        }
                        sum=a/b;
                        break;
                    case 5:
                        sum=Math.sin(a);
                         break;
                    case 6:
                        sum=Math.cos(a);
                        break;
                    case 7:
                        sum=Math.tan(a);
                        break;
                    case 8:
                        sum=Math.pow(a,b);
                        break;
                    case 9:
                        long l = Math.round(a);;
                        sum=Double.valueOf(Long.toBinaryString(l));
                        break;

                    default:
                        break;
                }


                sumtype=sum%1;
                if(sumtype>0){
                    pointCount=1;
                }
                s=""+sum;
                if(sumtype==0){
                    int end=(s.toString()).lastIndexOf(".");
                    String str=(s.toString()).substring(0, end);
                    s=""+Integer.parseInt(str);
                    pointCount=0;
                }
                if(flag){
                    text.setText(s);
                }
                a=Double.valueOf(s);
                option=0;
                flag=true;

            }

            if(btn.getId()==R.id.clear){
                text.setText("0");
                pointCount=0;
                option=0;
                sum=0;
                flag=true;
            }
        }
    };



}